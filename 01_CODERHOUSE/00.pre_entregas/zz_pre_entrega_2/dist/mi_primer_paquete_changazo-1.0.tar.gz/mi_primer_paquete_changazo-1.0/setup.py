from setuptools import setup

setup(
    name="mi_primer_paquete_changazo",
    version="1.0",
    author="tobias_changazo",
    description="segunda preentrega",
    author_email="coder@coder.com",
    packages=["modelo_clientes"]
)

